<form method="post" enctype="multipart/form-data" action="ewbpost.php">
    <div>        
        <textarea name="shtml"></textarea>
    </div>
    <button type="submit">Submit</button>
</form>