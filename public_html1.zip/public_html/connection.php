<?php
    $db_name = "id17589896_relational";
	$mysql_username = "id17589896_relationaldatabase";
	$mysql_password = "Tusharda@123";
	$server_name = "localhost";
	$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);
	
	

?>